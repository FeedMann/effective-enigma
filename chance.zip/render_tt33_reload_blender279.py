# Read-only OGF + OMF animation proof recording in Blender 2.79.
import bpy
import os
from mathutils import Vector

from io_scene_xray import xray_inject
xray_inject.register()
from stalker_tools.ogf import read as ogf_read
from stalker_tools.omf import read as omf_read

ROOT = '/home/user/tarkov_tt33_inspection'
OGF = os.path.join(ROOT, 'models_only', 'Escape From Tarkov TT-33 DUO', 'EFT TT-33 DUO', 'gamedata', 'meshes', 'anomaly_weapons', 'wpn_eft_tt33', 'wpn_eft_tt33_hud.ogf')
OMF = os.path.join(ROOT, 'animations_only', 'Escape From Tarkov TT-33 DUO', 'EFT TT-33 DUO', 'gamedata', 'meshes', 'anomaly_weapons', 'hud_animation', 'wpn_eft_tt33_new_hud_animation.omf')
OUT_BLEND = os.path.join(ROOT, 'tt33_reload_omf_blender279.blend')
OUT_VIDEO = os.path.join(ROOT, 'tt33_reload_nobump_blender279_proof.mp4')

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()
for mesh in list(bpy.data.meshes):
    bpy.data.meshes.remove(mesh)
for armature_data in list(bpy.data.armatures):
    bpy.data.armatures.remove(armature_data)

ogf_read.file(OGF)
mesh_objects = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
armature = [obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE'][0]

# Import the weapon's own OMF bank onto its matching HUD armature.
bpy.context.scene.objects.active = armature
armature.select = True
omf_read.file(OMF)
action = bpy.data.actions.get('reload_nobump')
assert action is not None
armature.animation_data_create().action = action
armature.data.pose_position = 'POSE'

# Use one neutral material: this video demonstrates mesh+armature motion,
# not legacy Blender 2.79 texture/shader compatibility.
material = bpy.data.materials.new('Animation proof material')
material.use_shadeless = True
material.use_transparency = False
material.alpha = 1.0
material.diffuse_color = (0.24, 0.32, 0.46)
for obj in mesh_objects:
    obj.data.materials.clear()
    obj.data.materials.append(material)
    for poly in obj.data.polygons:
        poly.material_index = 0

# Calculate static import bounds for a stable camera framing.
points = []
for obj in mesh_objects:
    for vertex in obj.data.vertices:
        points.append(obj.matrix_world * vertex.co)
minimum = Vector((min(p.x for p in points), min(p.y for p in points), min(p.z for p in points)))
maximum = Vector((max(p.x for p in points), max(p.y for p in points), max(p.z for p in points)))
center = (minimum + maximum) * 0.5
size = max((maximum - minimum).x, (maximum - minimum).y, (maximum - minimum).z)

scene = bpy.context.scene
scene.render.engine = 'BLENDER_RENDER'
scene.render.resolution_x = 640
scene.render.resolution_y = 400
scene.render.resolution_percentage = 100
scene.render.fps = 30
scene.frame_start = int(action.frame_range[0])
scene.frame_end = int(action.frame_range[1])
scene.world.horizon_color = (0.012, 0.018, 0.03)
scene.view_settings.view_transform = 'Default'
scene.view_settings.exposure = 0.0
scene.view_settings.gamma = 1.0

camera_data = bpy.data.cameras.new('Camera')
camera = bpy.data.objects.new('Camera', camera_data)
bpy.context.scene.objects.link(camera)
camera.location = center + Vector((size * 2.4, -size * 3.0, size * 1.55))
camera.rotation_euler = (center - camera.location).to_track_quat('-Z', 'Y').to_euler()
camera.data.lens = 58
scene.camera = camera

# Verify that the selected action really changes pose data before recording.
def pose_snapshot():
    return tuple((tuple(bone.location), tuple(bone.rotation_euler)) for bone in armature.pose.bones)

scene.frame_set(scene.frame_start)
start_pose = pose_snapshot()
scene.frame_set((scene.frame_start + scene.frame_end) // 2)
mid_pose = pose_snapshot()
scene.frame_set(scene.frame_end)
end_pose = pose_snapshot()
assert start_pose != mid_pose or mid_pose != end_pose, 'selected OMF action did not change the armature pose'

scene.render.image_settings.file_format = 'FFMPEG'
scene.render.ffmpeg.format = 'MPEG4'
scene.render.ffmpeg.codec = 'H264'
scene.render.ffmpeg.constant_rate_factor = 'MEDIUM'
scene.render.filepath = OUT_VIDEO

bpy.ops.wm.save_as_mainfile(filepath=OUT_BLEND)
scene.frame_set(scene.frame_start)
bpy.ops.render.render(animation=True)
print('XRAY_OMF_RECORD_OK action=%s frames=%d-%d fcurves=%d output=%s' % (
    action.name, scene.frame_start, scene.frame_end, len(action.fcurves), OUT_VIDEO
))
