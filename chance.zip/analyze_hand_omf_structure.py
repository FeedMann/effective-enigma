#!/usr/bin/env python3
import struct, sys
from pathlib import Path

p = Path(sys.argv[1])
data=p.read_bytes()

def chunks(data):
    out=[]; off=0
    while off < len(data):
        if off+8 > len(data): raise ValueError((off,len(data)))
        cid, size=struct.unpack_from('<II',data,off); off+=8
        # no compressed support for purposes of inspection
        out.append((cid,data[off:off+size]))
        off += size
    return out

def zstr(d,o):
    i=d.index(0,o)
    return d[o:i].decode('cp1251'),i+1

def parse_motion(d,n):
    name,o=zstr(d,0)
    length,=struct.unpack_from('<I',d,o);o+=4
    for _ in range(n):
        if o >= len(d): return None
        flags=d[o];o+=1
        # rotation
        o += 8 if flags&2 else (4+8*length)
        # translation
        if flags&1:
            o +=4+(6 if flags&4 else 3)*length+24
        else:
            o +=12
        if o>len(d): return None
    return (name,length,o)

root=chunks(data)
print('Outer chunks:', [(hex(i),len(d)) for i,d in root])
for cid, contents in root:
    print('outer',hex(cid),'first bytes',contents[:32].hex())
    try:
        inner=chunks(contents)
        print(' inner:', [(hex(i),len(x)) for i,x in inner])
        if cid==0:
            for i,x in inner[:2]: print('  count/chunk',i,x[:8].hex(), struct.unpack_from('<I',x)[0] if len(x)>=4 else None)
        else:
            vals=[]
            for innerid, x in inner:
                if innerid == 0: continue
                exact=[]
                for n in range(1,201):
                    q=parse_motion(x,n)
                    if q and q[2]==len(x): exact.append((n,q[0],q[1]))
                vals.append((hex(innerid),len(x),exact))
            print(' valid bone counts by motion:',vals)
    except Exception as e: print(' inner error',repr(e))
