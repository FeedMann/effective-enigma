# Read-only OGF + OMF compatibility test in Blender 2.79.
import bpy
import os

from io_scene_xray import xray_inject
xray_inject.register()
from stalker_tools.ogf import read as ogf_read
from stalker_tools.omf import read as omf_read

ROOT = '/home/user/tarkov_tt33_inspection'
OGF = os.path.join(ROOT, 'models_only', 'Escape From Tarkov TT-33 DUO', 'EFT TT-33 DUO', 'gamedata', 'meshes', 'anomaly_weapons', 'wpn_eft_tt33', 'wpn_eft_tt33_hud.ogf')
OMF = os.path.join(ROOT, 'animations_only', 'Escape From Tarkov TT-33 DUO', 'EFT TT-33 DUO', 'gamedata', 'meshes', 'anomaly_weapons', 'hud_animation', 'wpn_eft_tt33_new_hud_animation.omf')

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()
for mesh in list(bpy.data.meshes):
    bpy.data.meshes.remove(mesh)
for armature in list(bpy.data.armatures):
    bpy.data.armatures.remove(armature)

ogf_read.file(OGF)
armatures = [obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE']
assert len(armatures) == 1, len(armatures)
armature = armatures[0]
bpy.context.scene.objects.active = armature
armature.select = True
omf_read.file(OMF)

actions = sorted(bpy.data.actions, key=lambda action: action.name)
assert actions, 'OMF yielded no Blender actions'
for action in actions:
    print('XRAY_OMF_ACTION name=%s range=%s fcurves=%d' % (action.name, tuple(action.frame_range), len(action.fcurves)))

out = os.path.join(ROOT, 'tt33_hud_omf_imported_blender279.blend')
bpy.ops.wm.save_as_mainfile(filepath=out)
print('XRAY_OMF_IMPORT_OK armature_bones=%d actions=%d saved=%s' % (len(armature.data.bones), len(actions), out))
