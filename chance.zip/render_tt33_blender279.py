# Render proof for the read-only X-Ray OGF import in Blender 2.79.
import bpy
import os
import math
from mathutils import Vector

from io_scene_xray import xray_inject
xray_inject.register()
from stalker_tools.ogf import read

ROOT = '/home/user/tarkov_tt33_inspection/models_only'
SOURCE = os.path.join(
    ROOT, 'Escape From Tarkov TT-33 DUO', 'EFT TT-33 DUO', 'gamedata',
    'meshes', 'anomaly_weapons', 'wpn_eft_tt33', 'wpn_eft_tt33_hud.ogf'
)

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()
for mesh in list(bpy.data.meshes):
    bpy.data.meshes.remove(mesh)
for armature in list(bpy.data.armatures):
    bpy.data.armatures.remove(armature)

read.file(SOURCE)

mesh_objects = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
assert mesh_objects

# Use a neutral, texture-independent material for visual proof. This avoids
# treating game normal/bump maps as colour maps in Blender 2.79's old renderer.
proof_material = bpy.data.materials.new('Imported OGF - neutral proof material')
proof_material.use_shadeless = True
proof_material.use_transparency = False
proof_material.alpha = 1.0
proof_material.diffuse_color = (0.24, 0.32, 0.46)
for obj in mesh_objects:
    obj.data.materials.clear()
    obj.data.materials.append(proof_material)
    for polygon in obj.data.polygons:
        polygon.material_index = 0

# Find the actual imported mesh bounds in world space.
points = []
for obj in mesh_objects:
    for vertex in obj.data.vertices:
        points.append(obj.matrix_world * vertex.co)
minimum = Vector((min(p.x for p in points), min(p.y for p in points), min(p.z for p in points)))
maximum = Vector((max(p.x for p in points), max(p.y for p in points), max(p.z for p in points)))
center = (minimum + maximum) * 0.5
extent = maximum - minimum
size = max(extent.x, extent.y, extent.z)

scene = bpy.context.scene
scene.render.engine = 'BLENDER_RENDER'
scene.render.resolution_x = 1100
scene.render.resolution_y = 700
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = '/home/user/tarkov_tt33_inspection/tt33_hud_blender279_proof.png'
scene.world.horizon_color = (0.012, 0.018, 0.03)
scene.view_settings.view_transform = 'Default'
scene.view_settings.exposure = 0.0
scene.view_settings.gamma = 1.0

camera_data = bpy.data.cameras.new('Camera')
camera = bpy.data.objects.new('Camera', camera_data)
bpy.context.scene.objects.link(camera)
camera.location = center + Vector((size * 2.4, -size * 3.0, size * 1.55))
camera.rotation_euler = (center - camera.location).to_track_quat('-Z', 'Y').to_euler()
camera.data.lens = 58
scene.camera = camera

bpy.ops.wm.save_as_mainfile(filepath='/home/user/tarkov_tt33_inspection/tt33_hud_imported_blender279.blend')
bpy.ops.render.render(write_still=True)
print('XRAY_OGF_RENDER_OK bounds=%s to %s output=%s' % (tuple(minimum), tuple(maximum), scene.render.filepath))
