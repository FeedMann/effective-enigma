# Isolated read-only OGF import test.  No configs, scripts, sounds, or game runtime are used.
import bpy
import os

# The old X-Ray property package is registered directly in this isolated
# headless session.  Its menu/preferences UI is not needed for read-only import.
from io_scene_xray import xray_inject
xray_inject.register()

from stalker_tools.ogf import read

ROOT = '/home/user/tarkov_tt33_inspection/models_only'
SOURCE = os.environ.get('XRAY_SOURCE') or os.path.join(
    ROOT, 'Escape From Tarkov TT-33 DUO', 'EFT TT-33 DUO', 'gamedata',
    'meshes', 'anomaly_weapons', 'wpn_eft_tt33', 'wpn_eft_tt33_hud.ogf'
)

# Clean default scene.
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()
for mesh in list(bpy.data.meshes):
    bpy.data.meshes.remove(mesh)
for armature in list(bpy.data.armatures):
    bpy.data.armatures.remove(armature)

read.file(SOURCE)

meshes = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
arms = [obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE']
vertices = sum(len(obj.data.vertices) for obj in meshes)
triangles = sum(len(obj.data.polygons) for obj in meshes)

assert meshes, 'the OGF importer produced no meshes'
assert vertices > 0, vertices
assert triangles > 0, triangles

OUT = '/home/user/tarkov_tt33_inspection/tt33_hud_imported_blender279.blend'
bpy.ops.wm.save_as_mainfile(filepath=OUT)
print('XRAY_OGF_IMPORT_OK meshes=%d armatures=%d vertices=%d triangles=%d saved=%s' % (
    len(meshes), len(arms), vertices, triangles, OUT
))
