#!/usr/bin/env python3
import struct,sys
p=sys.argv[1]; d=open(p,'rb').read()
def chunks(d):
 o=0
 while o<len(d):
  cid,size=struct.unpack_from('<II',d,o);o+=8
  yield cid,d[o:o+size];o+=size
def z(d,o):
 e=d.index(b'\0',o); return d[o:e].decode('cp1251'),e+1
sm=dict(chunks(d))[0x0F]
o=0
v,parts=struct.unpack_from('<HH',sm,o);o+=4
print('version',v,'partitions',parts)
seen={}
for n in range(parts):
 name,o=z(sm,o); num,=struct.unpack_from('<H',sm,o);o+=2
 bs=[]
 for _ in range(num):
  b,o=z(sm,o); idx,=struct.unpack_from('<I',sm,o);o+=4
  bs.append((idx,b));seen[idx]=b
 print('\n{} ({}):'.format(name,num))
 for idx,b in bs: print('  {:2d} {}'.format(idx,b))
count,=struct.unpack_from('<H',sm,o);o+=2
print('\nmotions',count)
for _ in range(count):
 name,o=z(sm,o); flags,=struct.unpack_from('<I',sm,o);o+=4
 bone, motion=struct.unpack_from('<HH',sm,o);o+=4
 speed,power,accrue,falloff=struct.unpack_from('<4f',sm,o);o+=16
 marks,=struct.unpack_from('<I',sm,o);o+=4
 # Known bundle has zero marks; record anyway to avoid pretending complete.
 print(' ',name,'part/bone',bone,'motion',motion,'flags',hex(flags),'marks',marks)
 if marks: raise RuntimeError('marks need parser')
print('\nUnique indexed bones:',len(seen),'indices:',sorted(seen))
print('Bytes consumed:',o,'of',len(sm))
