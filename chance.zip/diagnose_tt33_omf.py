import bpy
import os
from io_scene_xray import xray_inject
xray_inject.register()
from stalker_tools.ogf import read as ogf_read
from stalker_tools.omf import read as omf_read
ROOT = '/home/user/tarkov_tt33_inspection'
OGF = os.path.join(ROOT, 'models_only', 'Escape From Tarkov TT-33 DUO', 'EFT TT-33 DUO', 'gamedata', 'meshes', 'anomaly_weapons', 'wpn_eft_tt33', 'wpn_eft_tt33_hud.ogf')
OMF = os.path.join(ROOT, 'animations_only', 'Escape From Tarkov TT-33 DUO', 'EFT TT-33 DUO', 'gamedata', 'meshes', 'anomaly_weapons', 'hud_animation', 'wpn_eft_tt33_new_hud_animation.omf')
ogf_read.file(OGF)
arm=[o for o in bpy.context.scene.objects if o.type == 'ARMATURE'][0]
bpy.context.scene.objects.active=arm
arm.select=True
omf_read.file(OMF)
a=bpy.data.actions['reload_nobump']
print('ARM BONES', [b.name for b in arm.pose.bones])
print('FC FIRST')
for fc in a.fcurves[:12]:
 vals=[p.co[1] for p in fc.keyframe_points]
 print(fc.data_path, fc.array_index, len(vals), min(vals), max(vals), vals[:3], vals[-3:])
arm.animation_data_create().action=a
for f in (0,1,30,57,80,115):
 bpy.context.scene.frame_set(f)
 print('FRAME',f)
 for bone in arm.pose.bones:
  print(bone.name, tuple(bone.location),tuple(bone.rotation_euler))
  break
 print('action?',arm.animation_data.action.name)
