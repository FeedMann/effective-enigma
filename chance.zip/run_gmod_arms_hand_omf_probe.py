# Controlled Blender 2.79 probe: public SMD arms supplied by the user + TT-33 hand OMF.
# It reads only the explicit SMD/OMF paths below and writes a separate .blend/render.
# This is a visual compatibility experiment, not an X-Ray/GMod export pipeline.
import bpy
import os
import math
from mathutils import Matrix, Vector, Euler

from io_scene_xray import xray_inject
xray_inject.register()
from stalker_tools.omf import read as omf_read

ROOT = '/home/user/tarkov_tt33_inspection'
SMD = os.path.join(ROOT, 'gmod_arms_probe', '8d7a3f28ba34eb5.smd')
HAND_OMF = os.path.join(
    ROOT, 'animations_only', 'Escape From Tarkov TT-33 DUO', 'EFT TT-33 DUO',
    'gamedata', 'meshes', 'anomaly_weapons', 'hud_hands_animation',
    'wpn_eft_tt33_new_hand_hud_animation.omf')
OUT_BLEND = os.path.join(ROOT, 'gmod_arms_tt33_hand_omf_probe_blender279.blend')
OUT_START = os.path.join(ROOT, 'gmod_arms_tt33_hand_omf_reload_frame000.png')
OUT_MID = os.path.join(ROOT, 'gmod_arms_tt33_hand_omf_reload_frame060.png')

# The OMF's own SM params identify these exact IDs/names.  Do not reorder.
TARGET_BONES = [
    'bip01',
    'l_clavicle', 'l_upperarm', 'l_forearm', 'l_forearm_twist', 'l_hand',
    'bip01_l_finger1', 'bip01_l_finger11', 'bip01_l_finger12',
    'bip01_l_finger2', 'bip01_l_finger21', 'bip01_l_finger22',
    'bip01_l_finger3', 'bip01_l_finger31', 'bip01_l_finger32',
    'bip01_l_finger4', 'bip01_l_finger41', 'bip01_l_finger42',
    'l_finger0', 'l_finger01', 'l_finger02',
    'lead_gun',
    'r_clavicle', 'r_upperarm', 'r_forearm', 'r_forearm_twist', 'r_hand',
    'bip01_r_finger1', 'bip01_r_finger11', 'bip01_r_finger12',
    'bip01_r_finger2', 'bip01_r_finger21', 'bip01_r_finger22',
    'bip01_r_finger3', 'bip01_r_finger31', 'bip01_r_finger32',
    'bip01_r_finger4', 'bip01_r_finger41', 'bip01_r_finger42',
    'r_finger0', 'r_finger01', 'r_finger02'
]
assert len(TARGET_BONES) == 42

# Target bone -> source bone index in this exact supplied SMD.
# The source contains additional wrist/ulna helper bones; their weights are
# folded into the nearest target forearm-twist bone below.
TARGET_SOURCE = {
    'bip01': 1,
    'l_clavicle': 23, 'l_upperarm': 24, 'l_forearm': 25,
    'l_forearm_twist': 26, 'l_hand': 28,
    'bip01_l_finger1': 32, 'bip01_l_finger11': 33, 'bip01_l_finger12': 34,
    'bip01_l_finger2': 35, 'bip01_l_finger21': 36, 'bip01_l_finger22': 37,
    'bip01_l_finger3': 38, 'bip01_l_finger31': 39, 'bip01_l_finger32': 40,
    'bip01_l_finger4': 41, 'bip01_l_finger41': 42, 'bip01_l_finger42': 43,
    'l_finger0': 29, 'l_finger01': 30, 'l_finger02': 31,
    'lead_gun': 6,
    'r_clavicle': 2, 'r_upperarm': 3, 'r_forearm': 4,
    'r_forearm_twist': 5, 'r_hand': 7,
    'bip01_r_finger1': 11, 'bip01_r_finger11': 12, 'bip01_r_finger12': 13,
    'bip01_r_finger2': 14, 'bip01_r_finger21': 15, 'bip01_r_finger22': 16,
    'bip01_r_finger3': 17, 'bip01_r_finger31': 18, 'bip01_r_finger32': 19,
    'bip01_r_finger4': 20, 'bip01_r_finger41': 21, 'bip01_r_finger42': 22,
    'r_finger0': 8, 'r_finger01': 9, 'r_finger02': 10
}
SOURCE_TO_TARGET = {source: target for target, source in TARGET_SOURCE.items()}
# Extra Source helpers not represented by the 42-bone X-Ray OMF target.
SOURCE_TO_TARGET[27] = 'l_forearm_twist'
SOURCE_TO_TARGET[6] = 'lead_gun'  # no source vertices use this helper
# A Source wrist/ulna pair must share this closest available target twist bone.
SOURCE_TO_TARGET[5] = 'r_forearm_twist'
SOURCE_TO_TARGET[6] = 'r_forearm_twist'

PARENTS = {
    'l_clavicle': 'bip01', 'l_upperarm': 'l_clavicle', 'l_forearm': 'l_upperarm',
    'l_forearm_twist': 'l_forearm', 'l_hand': 'l_forearm',
    'bip01_l_finger1': 'l_hand', 'bip01_l_finger11': 'bip01_l_finger1', 'bip01_l_finger12': 'bip01_l_finger11',
    'bip01_l_finger2': 'l_hand', 'bip01_l_finger21': 'bip01_l_finger2', 'bip01_l_finger22': 'bip01_l_finger21',
    'bip01_l_finger3': 'l_hand', 'bip01_l_finger31': 'bip01_l_finger3', 'bip01_l_finger32': 'bip01_l_finger31',
    'bip01_l_finger4': 'l_hand', 'bip01_l_finger41': 'bip01_l_finger4', 'bip01_l_finger42': 'bip01_l_finger41',
    'l_finger0': 'l_hand', 'l_finger01': 'l_finger0', 'l_finger02': 'l_finger01',
    'lead_gun': 'bip01',
    'r_clavicle': 'bip01', 'r_upperarm': 'r_clavicle', 'r_forearm': 'r_upperarm',
    'r_forearm_twist': 'r_forearm', 'r_hand': 'r_forearm',
    'bip01_r_finger1': 'r_hand', 'bip01_r_finger11': 'bip01_r_finger1', 'bip01_r_finger12': 'bip01_r_finger11',
    'bip01_r_finger2': 'r_hand', 'bip01_r_finger21': 'bip01_r_finger2', 'bip01_r_finger22': 'bip01_r_finger21',
    'bip01_r_finger3': 'r_hand', 'bip01_r_finger31': 'bip01_r_finger3', 'bip01_r_finger32': 'bip01_r_finger31',
    'bip01_r_finger4': 'r_hand', 'bip01_r_finger41': 'bip01_r_finger4', 'bip01_r_finger42': 'bip01_r_finger41',
    'r_finger0': 'r_hand', 'r_finger01': 'r_finger0', 'r_finger02': 'r_finger01'
}


def parse_smd(path):
    lines = open(path, 'r').read().splitlines()
    nodes_start = lines.index('nodes') + 1
    nodes_end = lines.index('end', nodes_start)
    nodes = {}
    for line in lines[nodes_start:nodes_end]:
        # id "name" parent
        a, rest = line.split(' ', 1)
        name, parent = rest.rsplit(' ', 1)
        nodes[int(a)] = (name.strip()[1:-1], int(parent))

    skel_start = lines.index('skeleton') + 1
    time_line = skel_start
    assert lines[time_line].strip() == 'time 0'
    skel_end = lines.index('end', time_line)
    transforms = {}
    for line in lines[time_line + 1:skel_end]:
        f = line.split()
        transforms[int(f[0])] = tuple(float(x) for x in f[1:])

    tri_start = lines.index('triangles') + 1
    tri_end = lines.index('end', tri_start)
    verts, faces, uvs, source_weights, tri_materials = [], [], [], [], []
    i = tri_start
    while i < tri_end:
        material = lines[i].strip()
        i += 1
        face = []
        for _ in range(3):
            f = lines[i].split()
            i += 1
            verts.append((float(f[1]), float(f[2]), float(f[3])))
            uvs.append((float(f[7]), 1.0 - float(f[8])))
            count = int(f[9])
            weights = []
            if count:
                for k in range(count):
                    bone = int(f[10 + k * 2])
                    weight = float(f[11 + k * 2])
                    weights.append((bone, weight))
            else:
                weights.append((int(f[0]), 1.0))
            source_weights.append(weights)
            face.append(len(verts) - 1)
        faces.append(face)
        tri_materials.append(material)
    return nodes, transforms, verts, faces, uvs, source_weights, tri_materials


def source_world_matrices(nodes, transforms):
    result = {}
    def world(index):
        if index in result:
            return result[index]
        px, py, pz, rx, ry, rz = transforms[index]
        local = Matrix.Translation(Vector((px, py, pz))) * Euler((rx, ry, rz), 'XYZ').to_matrix().to_4x4()
        parent = nodes[index][1]
        result[index] = local if parent < 0 else world(parent) * local
        return result[index]
    for index in nodes:
        world(index)
    return result


def clean_scene():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete()
    for mesh in list(bpy.data.meshes): bpy.data.meshes.remove(mesh)
    for arm in list(bpy.data.armatures): bpy.data.armatures.remove(arm)


def make_armature(nodes, transforms):
    worlds = source_world_matrices(nodes, transforms)
    arm_data = bpy.data.armatures.new('TT33_OMF_Mapped_GMod_Arms_Rig')
    arm_obj = bpy.data.objects.new('TT33_OMF_Mapped_GMod_Arms_Rig', arm_data)
    bpy.context.scene.objects.link(arm_obj)
    bpy.context.scene.objects.active = arm_obj
    arm_obj.select = True
    bpy.ops.object.mode_set(mode='EDIT')
    edit = {}
    # Creation order is deliberately the OMF stream order.
    for target in TARGET_BONES:
        source = TARGET_SOURCE[target]
        world = worlds[source]
        eb = arm_data.edit_bones.new(target)
        eb.head = world.to_translation()
        # Point toward the first represented child; leaf bones extend along rest Y.
        child_targets = [x for x in TARGET_BONES if PARENTS.get(x) == target]
        if child_targets:
            tail_pos = worlds[TARGET_SOURCE[child_targets[0]]].to_translation()
            if (tail_pos - eb.head).length > 0.01:
                eb.tail = tail_pos
            else:
                eb.tail = eb.head + world.to_3x3() * Vector((0, 2, 0))
        else:
            eb.tail = eb.head + world.to_3x3() * Vector((0, 2, 0))
        if (eb.tail - eb.head).length < 0.01:
            eb.tail = eb.head + Vector((0, 2, 0))
        edit[target] = eb
    for target, parent in PARENTS.items():
        edit[target].parent = edit[parent]
        edit[target].use_connect = False
    bpy.ops.object.mode_set(mode='OBJECT')
    actual = [b.name for b in arm_data.bones]
    assert actual == TARGET_BONES, 'Blender bone order differs from OMF order: %r' % actual
    return arm_obj


def make_mesh(verts, faces, uvs, source_weights, tri_materials, arm_obj):
    mesh = bpy.data.meshes.new('GMod_Arms_SMD_Mesh')
    mesh.from_pydata(verts, [], faces)
    mesh.update(calc_edges=True)
    obj = bpy.data.objects.new('GMod_Arms_SMD_Mesh', mesh)
    bpy.context.scene.objects.link(obj)

    skin = bpy.data.materials.new('hands_skin_preview')
    skin.diffuse_color = (0.55, 0.24, 0.13)
    skin.specular_intensity = 0.12
    sleeve = bpy.data.materials.new('sleeves_preview')
    sleeve.diffuse_color = (0.075, 0.16, 0.095)
    sleeve.specular_intensity = 0.06
    mesh.materials.append(skin)
    mesh.materials.append(sleeve)
    for poly, material in zip(mesh.polygons, tri_materials):
        poly.material_index = 1 if 'sleeves' in material.lower() else 0

    mesh.uv_textures.new('UVMap')
    for loop, uv in zip(mesh.uv_layers.active.data, uvs):
        loop.uv = uv

    groups = {name: obj.vertex_groups.new(name=name) for name in TARGET_BONES}
    for vi, weights in enumerate(source_weights):
        merged = {}
        for source, weight in weights:
            target = SOURCE_TO_TARGET.get(source)
            if target:
                merged[target] = merged.get(target, 0.0) + weight
        for target, weight in merged.items():
            groups[target].add([vi], weight, 'REPLACE')

    modifier = obj.modifiers.new('TT33 hand OMF rig', 'ARMATURE')
    modifier.object = arm_obj
    return obj


def make_camera_and_lights():
    # Source-engine units in the SMD place this model near z=55.
    camera_data = bpy.data.cameras.new('Camera')
    camera = bpy.data.objects.new('Camera', camera_data)
    bpy.context.scene.objects.link(camera)
    bpy.context.scene.camera = camera
    camera.location = (105, -135, 88)
    target = Vector((0, 0, 50))
    camera.rotation_euler = (target - camera.location).to_track_quat('-Z', 'Y').to_euler()
    camera.data.lens = 55

    for loc, energy, size in [((45, -45, 135), 1300, 45), ((-75, -30, 85), 850, 35), ((0, 65, 70), 700, 30)]:
        light_data = bpy.data.lamps.new('Area', 'AREA')
        light_data.energy = energy
        light_data.size = size
        light = bpy.data.objects.new('Area', light_data)
        bpy.context.scene.objects.link(light)
        light.location = loc
        light.rotation_euler = (target - light.location).to_track_quat('-Z', 'Y').to_euler()


clean_scene()
nodes, transforms, verts, faces, uvs, weights, tri_materials = parse_smd(SMD)
assert len(nodes) == 46
assert len(faces) == 5222
armature = make_armature(nodes, transforms)
mesh_obj = make_mesh(verts, faces, uvs, weights, tri_materials, armature)

# The OMF parser is intentionally used only after the target rig order/count/names have
# been rebuilt from its SM params metadata.
bpy.context.scene.objects.active = armature
armature.select = True
omf_read.file(HAND_OMF)
actions = sorted(bpy.data.actions, key=lambda action: action.name)
assert len(actions) == 19, len(actions)
reload_action = bpy.data.actions['eft_tt33_new_reload_nobump']
assert int(reload_action.frame_range[0]) == 0 and int(reload_action.frame_range[1]) == 115
assert len(reload_action.fcurves) == 252
armature.animation_data_create()
armature.animation_data.action = reload_action

# Demonstrate actual pose variation in a target hand bone, not merely action creation.
scene = bpy.context.scene
scene.frame_set(0)
start = tuple(armature.pose.bones['r_hand'].rotation_euler)
scene.frame_set(60)
mid = tuple(armature.pose.bones['r_hand'].rotation_euler)
assert start != mid, (start, mid)

make_camera_and_lights()
scene.render.engine = 'BLENDER_RENDER'
scene.render.resolution_x = 900
scene.render.resolution_y = 650
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.world.horizon_color = (0.025, 0.025, 0.025)

scene.frame_set(0)
scene.render.filepath = OUT_START
bpy.ops.render.render(write_still=True)
scene.frame_set(60)
scene.render.filepath = OUT_MID
bpy.ops.render.render(write_still=True)
bpy.ops.wm.save_as_mainfile(filepath=OUT_BLEND)

print('GMOD_ARMS_OMF_PROBE_OK source_nodes=%d faces=%d target_bones=%d actions=%d reload_fcurves=%d r_hand_frame0=%r r_hand_frame60=%r saved=%s' % (
    len(nodes), len(faces), len(TARGET_BONES), len(actions), len(reload_action.fcurves), start, mid, OUT_BLEND))
